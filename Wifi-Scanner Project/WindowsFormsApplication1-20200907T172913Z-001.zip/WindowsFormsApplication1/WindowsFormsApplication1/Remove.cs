﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    class Remove
    {
        public void clear(ListView listview2)
        {
            listview2.Items.Clear();

        }
    }
}
